#!/usr/bin/env bash
# genie-side RDMA diagnostic responder (genie is NOT SEV → ordinary memory).
# Re-listens between rounds so the guest can run several client probes.
# Reuses firewall-open port 7101 (stop mnd first if it holds it).
set -u
cd "$(dirname "$0")"
PORT=${PORT:-7101}
SIZE=${SIZE:-65536}
DEV=${DM_RDMA_DEV:-$(ibv_devices 2>/dev/null | awk 'NR>2{print $1; exit}')}
echo "genie responder: dev=$DEV port=$PORT size=$SIZE (ordinary malloc memory)"
ibv_devinfo -d "$DEV" 2>/dev/null | grep -E "state|port_lid|link_layer"
case "${1:-loop}" in
  once) ./snp_rdma_test --server --malloc -p "$PORT" -d "$DEV" -s "$SIZE" ;;
  loop) while true; do
          echo "--- listening (server, malloc) ---"
          ./snp_rdma_test --server --malloc -p "$PORT" -d "$DEV" -s "$SIZE" || echo "server rc=$?"
        done ;;
esac

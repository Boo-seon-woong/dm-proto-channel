// SPDX-License-Identifier: GPL-2.0
/*
 * snp_rdma_test - Minimal RDMA_WRITE test that uses /dev/snp_shared as
 * the MR backing buffer on the SEV-SNP server side.
 *
 * Roles:
 *   --server      : passive side. Allocates a buffer (via /dev/snp_shared
 *                   by default), registers it as a remote-writable MR,
 *                   waits over TCP for the client to complete its
 *                   RDMA_WRITE, then verifies the pattern.
 *   --client IP   : active side. Allocates a buffer (regular malloc by
 *                   default), fills with a deterministic byte pattern,
 *                   issues a single RDMA_WRITE to the server's MR.
 *
 * The same binary runs on both sides; the side running inside the SNP
 * guest should pass -M /dev/snp_shared (default) while the peer (genie)
 * can pass --malloc to use ordinary heap memory.
 *
 * TCP control channel runs over IPoIB IP (default port 18515).
 */

#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdint.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include <poll.h>
#include <infiniband/verbs.h>
#include <infiniband/mlx5dv.h>

#define DEFAULT_PORT 18515
#define DEFAULT_SIZE (4UL * 1024 * 1024) /* 4 MiB */
#define DEFAULT_SHARED_PATH "/dev/snp_shared"
#define DEFAULT_IB_PORT 1

/* CQ ring entries (--cq). Under SEV the CQ consumer-index doorbell record is
 * a bounced umem the HCA reads stale (frozen at its map-time value), so the
 * HCA declares CQ overrun — killing the QP — after exactly 2*cq_entries CQEs.
 * A larger ring moves that wall proportionally. */
static int cq_entries = 256;

struct conn_info {
	uint64_t vaddr;
	uint32_t rkey;
	uint32_t qpn;
	uint32_t psn;
	uint16_t lid;
	uint16_t pad;
} __attribute__((packed));

struct mr_info {
	uint64_t vaddr;
	uint32_t rkey;
	uint32_t pad;
} __attribute__((packed));

struct bench_stats {
	unsigned long long count;
	unsigned long long min_ns;
	unsigned long long max_ns;
	long double sum_ns;
};

struct rdma_ctx {
	struct ibv_context *ctx;
	struct ibv_pd *pd;
	struct ibv_cq *cq;
	struct ibv_comp_channel *chan;
	struct ibv_qp *qp;
	struct ibv_mr *mr;
	void *buf;
	size_t size;
	int dev_fd; /* /dev/snp_shared fd, or -1 */
	uint16_t local_lid;
	uint32_t local_psn;
};

static unsigned char pattern_byte(size_t i, unsigned int iter)
{
	return (unsigned char)((i + iter) & 0xff);
}

static unsigned long long now_ns(void)
{
	struct timespec ts;

	clock_gettime(CLOCK_MONOTONIC, &ts);
	return (unsigned long long)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
}

/* Bounded CQ poll: returns 1=completion, 0=timeout (CQE never CPU-visible),
 * -1=poll error. timeout_ms<=0 keeps the original infinite busy-poll. This is
 * the instrumentation that distinguishes "completion not visible" (a SEV
 * bounce-sync failure) from a genuine hang. */
/* Event-driven completion wait. On the SEV-patched kernel, the completion
 * INTERRUPT handler (mlx5_ib_cq_comp) dma_syncs the CQ umem before waking us
 * via the completion channel — so blocking on ibv_get_cq_event guarantees the
 * bounced CQE is CPU-visible when we then poll. Busy-polling can't do this: it
 * never enters the kernel on the completion path. Returns 1=completion,
 * 0=timeout, -1=error. */
static int poll_cqe(struct rdma_ctx *r, struct ibv_wc *wc, int timeout_ms)
{
	unsigned long long deadline =
		timeout_ms > 0 ? now_ns() + (unsigned long long)timeout_ms * 1000000ULL : 0;
	for (;;) {
		if (ibv_req_notify_cq(r->cq, 0))
			return -1;
		/* poll once in case it's already delivered+synced */
		int n = ibv_poll_cq(r->cq, 1, wc);
		if (n < 0)
			return -1;
		if (n > 0)
			return 1;
		int left = deadline ? (int)((long long)(deadline - now_ns()) / 1000000LL) : -1;
		if (deadline && left <= 0)
			return 0;
		struct pollfd pfd = { .fd = r->chan->fd, .events = POLLIN };
		int pr = poll(&pfd, 1, left);
		if (pr < 0)
			return -1;
		if (pr == 0)
			continue; /* re-check deadline / re-arm */
		struct ibv_cq *ev_cq;
		void *ev_ctx;
		if (ibv_get_cq_event(r->chan, &ev_cq, &ev_ctx))
			return -1;
		ibv_ack_cq_events(ev_cq, 1);
		/* the interrupt (and its kernel dma_sync) has now run; poll again */
		n = ibv_poll_cq(r->cq, 1, wc);
		if (n < 0)
			return -1;
		if (n > 0)
			return 1;
	}
}

/* --- pre-arm sequencing (userspace fix for the post→arm race) ------------
 * poll_cqe() arms INSIDE the wait, i.e. only after the caller has already
 * posted — a completion landing before that arm is written to the CQ bounce
 * with the CQ disarmed: no interrupt, no kernel dma_sync, and ibv_poll_cq
 * reads a stale ring forever (the --bw stall). Discipline instead:
 *     arm_cq();  ibv_post_send();  wait_armed_cqe();
 * Arming first guarantees the completion is written while armed, so it raises
 * the completion interrupt and the patched mlx5_ib_cq_comp syncs the CQ
 * bounce before the event wakes us. ibv_req_notify_cq is a userspace doorbell
 * on mlx5 (no syscall), so the per-op cost is negligible. */
static int arm_cq(struct rdma_ctx *r)
{
	return ibv_req_notify_cq(r->cq, 0);
}

/* Wait for one CQE on a CQ that was armed BEFORE the WR was posted. Never
 * re-arms after a post (that would reopen the race); the defensive re-arm
 * below only runs after an event whose sync found the ring empty (spurious
 * event — nothing was pending, so nothing can be stranded by re-arming).
 * Returns 1=completion, 0=timeout, -1=error, like poll_cqe(). */
static int wait_armed_cqe(struct rdma_ctx *r, struct ibv_wc *wc, int timeout_ms)
{
	unsigned long long deadline =
		timeout_ms > 0 ? now_ns() + (unsigned long long)timeout_ms * 1000000ULL : 0;
	for (;;) {
		/* the interrupt (and its kernel dma_sync) may already have run */
		int n = ibv_poll_cq(r->cq, 1, wc);
		if (n)
			return n < 0 ? -1 : 1;
		int left = deadline ? (int)((long long)(deadline - now_ns()) / 1000000LL) : -1;
		if (deadline && left <= 0)
			return 0;
		struct pollfd pfd = { .fd = r->chan->fd, .events = POLLIN };
		int pr = poll(&pfd, 1, left);
		if (pr < 0)
			return -1;
		if (pr == 0)
			continue; /* re-check deadline */
		struct ibv_cq *ev_cq;
		void *ev_ctx;
		if (ibv_get_cq_event(r->chan, &ev_cq, &ev_ctx))
			return -1;
		ibv_ack_cq_events(ev_cq, 1);
		n = ibv_poll_cq(r->cq, 1, wc);
		if (n)
			return n < 0 ? -1 : 1;
		if (arm_cq(r))
			return -1;
		n = ibv_poll_cq(r->cq, 1, wc);
		if (n)
			return n < 0 ? -1 : 1;
	}
}

/* Sum of all mlx5 IRQ counts in /proc/interrupts. Stall diagnostics: an
 * unchanged count at a stall means the completion interrupt never fired
 * (notification lost); a bumped count means the IRQ fired but the CQE still
 * is not CPU-visible (sync failure — a deeper problem than arm ordering). */
static unsigned long long mlx5_irq_total(void)
{
	FILE *f = fopen("/proc/interrupts", "r");
	char line[1024];
	unsigned long long total = 0;

	if (!f)
		return 0;
	while (fgets(line, sizeof(line), f)) {
		char *p;

		if (!strstr(line, "mlx5"))
			continue;
		p = strchr(line, ':');
		if (!p)
			continue;
		p++;
		while (*p) {
			char *end;
			unsigned long long v = strtoull(p, &end, 10);

			if (end == p)
				break;
			total += v;
			p = end;
		}
	}
	fclose(f);
	return total;
}

static void bw_stall_diag(struct rdma_ctx *r, unsigned long long irq0)
{
	struct ibv_qp_attr qa;
	struct ibv_qp_init_attr qia;
	unsigned long long irq1 = mlx5_irq_total();

	if (!ibv_query_qp(r->qp, &qa, IBV_QP_STATE, &qia))
		fprintf(stderr, "[client] BW diag: QP state=%d (%s)\n", qa.qp_state,
			qa.qp_state == IBV_QPS_RTS ? "RTS — QP alive; completion/notification lost" :
			qa.qp_state == IBV_QPS_ERR ? "ERR — QP died (bad WQE fetch / flush)" :
			qa.qp_state == IBV_QPS_SQE ? "SQE — send queue error" : "other");
	else
		fprintf(stderr, "[client] BW diag: ibv_query_qp failed\n");
	fprintf(stderr, "[client] BW diag: mlx5 irqs start=%llu stall=%llu (delta %llu)\n",
		irq0, irq1, irq1 - irq0);
}

static void stats_add(struct bench_stats *s, unsigned long long ns)
{
	if (s->count == 0 || ns < s->min_ns)
		s->min_ns = ns;
	if (s->count == 0 || ns > s->max_ns)
		s->max_ns = ns;
	s->count++;
	s->sum_ns += ns;
}

static void stats_print(const char *role, const char *name,
			const struct bench_stats *s)
{
	if (!s->count)
		return;
	fprintf(stderr,
		"[%s] BENCH %s: count=%llu min=%.2f us mean=%.2Lf us max=%.2f us\n",
		role, name, s->count, s->min_ns / 1000.0,
		(s->sum_ns / s->count) / 1000.0L, s->max_ns / 1000.0);
}

static void bench_summary(const char *role, size_t size, unsigned int iters,
			  unsigned long long total_ns)
{
	long double mib = ((long double)size * iters) / (1024.0L * 1024.0L);
	long double sec = (long double)total_ns / 1000000000.0L;

	fprintf(stderr,
		"[%s] BENCH total: iters=%u bytes_per_iter=%zu total=%.2Lf us throughput=%.2Lf MiB/s\n",
		role, iters, size, (long double)total_ns / 1000.0L,
		sec > 0 ? mib / sec : 0.0L);
}

static void fill_pattern(void *buf, size_t size, unsigned int iter)
{
	for (size_t i = 0; i < size; i++)
		((unsigned char *)buf)[i] = pattern_byte(i, iter);
}

static void dump_first64(const void *buf)
{
	for (int i = 0; i < 64; i++) {
		fprintf(stderr, "%02x ", ((const unsigned char *)buf)[i]);
		if (i % 16 == 15)
			fprintf(stderr, "\n  ");
	}
}

static size_t count_pattern_mismatches(const void *buf, size_t size,
				       unsigned int iter, size_t *first_bad)
{
	size_t mismatches = 0;

	*first_bad = 0;
	for (size_t i = 0; i < size; i++) {
		if (((const unsigned char *)buf)[i] != pattern_byte(i, iter)) {
			if (mismatches == 0)
				*first_bad = i;
			mismatches++;
		}
	}
	return mismatches;
}

static void *alloc_buffer(size_t size, const char *path, int *out_fd)
{
	if (!path) {
		void *p;
		if (posix_memalign(&p, 4096, size))
			return NULL;
		memset(p, 0, size);
		*out_fd = -1;
		return p;
	}

	int fd = open(path, O_RDWR);
	if (fd < 0) {
		fprintf(stderr, "open(%s): %s\n", path, strerror(errno));
		return NULL;
	}
	void *p = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if (p == MAP_FAILED) {
		fprintf(stderr, "mmap(%s, %zu): %s\n", path, size,
			strerror(errno));
		close(fd);
		return NULL;
	}
	*out_fd = fd;
	return p;
}

static int register_mr(struct rdma_ctx *r, void *buf, size_t size)
{
	r->mr = ibv_reg_mr(r->pd, buf, size,
			   IBV_ACCESS_LOCAL_WRITE |
				   IBV_ACCESS_REMOTE_WRITE |
				   IBV_ACCESS_REMOTE_READ |
				   IBV_ACCESS_REMOTE_ATOMIC);
	if (!r->mr) {
		fprintf(stderr, "ibv_reg_mr(%p, %zu): %s\n", buf, size,
			strerror(errno));
		return -1;
	}
	return 0;
}

static struct mr_info make_mr_info(const struct rdma_ctx *r)
{
	return (struct mr_info){
		.vaddr = (uint64_t)(uintptr_t)r->buf,
		.rkey = r->mr->rkey,
		.pad = 0,
	};
}

static int setup_qp(struct rdma_ctx *r, const char *dev_name, int ib_port,
		    void *buf, size_t size)
{
	struct ibv_device **list = ibv_get_device_list(NULL);
	struct ibv_device *dev = NULL;

	if (!list) {
		perror("ibv_get_device_list");
		return -1;
	}
	if (dev_name) {
		for (int i = 0; list[i]; i++) {
			if (!strcmp(ibv_get_device_name(list[i]), dev_name)) {
				dev = list[i];
				break;
			}
		}
		if (!dev) {
			fprintf(stderr, "ib device '%s' not found\n", dev_name);
			ibv_free_device_list(list);
			return -1;
		}
	} else {
		dev = list[0];
		fprintf(stderr, "using default device: %s\n",
			ibv_get_device_name(dev));
	}

	r->ctx = ibv_open_device(dev);
	ibv_free_device_list(list);
	if (!r->ctx) {
		perror("ibv_open_device");
		return -1;
	}

	r->pd = ibv_alloc_pd(r->ctx);
	if (!r->pd) {
		perror("ibv_alloc_pd");
		return -1;
	}

	r->chan = ibv_create_comp_channel(r->ctx);
	if (!r->chan) {
		perror("ibv_create_comp_channel");
		return -1;
	}
	r->cq = ibv_create_cq(r->ctx, cq_entries, NULL, r->chan, 0);
	if (!r->cq) {
		perror("ibv_create_cq");
		return -1;
	}

	r->buf = buf;
	r->size = size;
	if (register_mr(r, buf, size))
		return -1;

	struct ibv_qp_init_attr qp_init = {
		.send_cq = r->cq,
		.recv_cq = r->cq,
		.cap = { .max_send_wr = 128, .max_recv_wr = 16,
			 .max_send_sge = 1, .max_recv_sge = 1 },
		.qp_type = IBV_QPT_RC,
	};
	r->qp = ibv_create_qp(r->pd, &qp_init);
	if (!r->qp) {
		perror("ibv_create_qp");
		return -1;
	}

	struct ibv_qp_attr attr = {
		.qp_state = IBV_QPS_INIT,
		.pkey_index = 0,
		.port_num = ib_port,
		.qp_access_flags = IBV_ACCESS_REMOTE_WRITE |
				   IBV_ACCESS_REMOTE_READ,
	};
	if (ibv_modify_qp(r->qp, &attr,
			  IBV_QP_STATE | IBV_QP_PKEY_INDEX | IBV_QP_PORT |
				  IBV_QP_ACCESS_FLAGS)) {
		perror("modify QP -> INIT");
		return -1;
	}

	struct ibv_port_attr pa;
	if (ibv_query_port(r->ctx, ib_port, &pa)) {
		perror("ibv_query_port");
		return -1;
	}
	r->local_lid = pa.lid;
	srand48(time(NULL) ^ getpid());
	r->local_psn = lrand48() & 0xffffff;
	return 0;
}

static int qp_to_rtr_rts(struct rdma_ctx *r, const struct conn_info *remote,
			 int ib_port)
{
	struct ibv_qp_attr attr = {
		.qp_state = IBV_QPS_RTR,
		.path_mtu = IBV_MTU_4096,
		.dest_qp_num = remote->qpn,
		.rq_psn = remote->psn,
		.max_dest_rd_atomic = 1,
		.min_rnr_timer = 12,
		.ah_attr = {
			.is_global = 0,
			.dlid = remote->lid,
			.sl = 0,
			.src_path_bits = 0,
			.port_num = ib_port,
		},
	};
	if (ibv_modify_qp(r->qp, &attr,
			  IBV_QP_STATE | IBV_QP_AV | IBV_QP_PATH_MTU |
				  IBV_QP_DEST_QPN | IBV_QP_RQ_PSN |
				  IBV_QP_MAX_DEST_RD_ATOMIC |
				  IBV_QP_MIN_RNR_TIMER)) {
		perror("modify QP -> RTR");
		return -1;
	}

	attr.qp_state = IBV_QPS_RTS;
	attr.timeout = 14;
	attr.retry_cnt = 7;
	attr.rnr_retry = 7;
	attr.sq_psn = r->local_psn;
	attr.max_rd_atomic = 1;
	if (ibv_modify_qp(r->qp, &attr,
			  IBV_QP_STATE | IBV_QP_TIMEOUT | IBV_QP_RETRY_CNT |
				  IBV_QP_RNR_RETRY | IBV_QP_SQ_PSN |
				  IBV_QP_MAX_QP_RD_ATOMIC)) {
		perror("modify QP -> RTS");
		return -1;
	}
	return 0;
}

static int read_full(int fd, void *buf, size_t n)
{
	size_t off = 0;
	while (off < n) {
		ssize_t r = read(fd, (char *)buf + off, n - off);
		if (r <= 0)
			return -1;
		off += r;
	}
	return 0;
}

static int write_full(int fd, const void *buf, size_t n)
{
	size_t off = 0;
	while (off < n) {
		ssize_t r = write(fd, (const char *)buf + off, n - off);
		if (r <= 0)
			return -1;
		off += r;
	}
	return 0;
}

static void flush_cpu_cache(void *buf, size_t size)
{
#if defined(__x86_64__) || defined(__i386__)
	uintptr_t start = (uintptr_t)buf & ~(uintptr_t)63;
	uintptr_t end = (uintptr_t)buf + size;

	for (uintptr_t p = start; p < end; p += 64)
		__builtin_ia32_clflush((const void *)p);
	__sync_synchronize();
#else
	msync(buf, size, MS_SYNC);
#endif
}

static int tcp_listen_accept(int port)
{
	int ls = socket(AF_INET, SOCK_STREAM, 0);
	int yes = 1;
	setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
	struct sockaddr_in addr = {
		.sin_family = AF_INET,
		.sin_port = htons(port),
		.sin_addr.s_addr = INADDR_ANY,
	};
	if (bind(ls, (struct sockaddr *)&addr, sizeof(addr))) {
		perror("bind");
		return -1;
	}
	if (listen(ls, 1)) {
		perror("listen");
		return -1;
	}
	fprintf(stderr, "[server] waiting on TCP port %d ...\n", port);
	int s = accept(ls, NULL, NULL);
	close(ls);
	if (s < 0)
		perror("accept");
	return s;
}

static int tcp_connect(const char *ip, int port)
{
	int s = socket(AF_INET, SOCK_STREAM, 0);
	struct sockaddr_in addr = { .sin_family = AF_INET,
				    .sin_port = htons(port) };
	inet_pton(AF_INET, ip, &addr.sin_addr);
	if (connect(s, (struct sockaddr *)&addr, sizeof(addr))) {
		fprintf(stderr, "connect %s:%d: %s\n", ip, port,
			strerror(errno));
		close(s);
		return -1;
	}
	return s;
}

static void usage(const char *p)
{
	fprintf(stderr,
		"Usage:\n"
		"  Server: %s --server [-d <ibdev>] [-s <bytes>] [-M <path>|--malloc] [--server-flush-before-verify] [--server-dereg-before-verify] [--sync-proto --iters N] [--bench]\n"
		"  Client: %s --client <peer-ip> [-d <ibdev>] [-s <bytes>] [-M <path>|--malloc] [--readback] [--sync-proto --iters N] [--bench]\n"
		"\n"
		"Options:\n"
		"  --server, -S            run as RDMA-Write target\n"
		"  --client IP, -C IP      run as RDMA-Write source against IP\n"
		"  --port, -p N            TCP port for control channel (default %d)\n"
		"  --size, -s N            buffer size in bytes (default %lu)\n"
		"  --device, -d NAME       IB verbs device name (default: first)\n"
		"  --ib-port, -P N         IB port number (default %d)\n"
		"  --shared-path, -M PATH  /dev/snp_shared path (default %s)\n"
		"  --malloc, -m            use posix_memalign instead of -M\n"
		"  --server-flush-before-verify\n"
		"                           server flushes CPU cache after client signal, before verify\n"
		"  --server-dereg-before-verify\n"
		"                           server deregisters MR after client signal, before verify\n"
		"  --sync-proto            iterative SWIOTLB sync prototype: server deregisters MR\n"
		"                           after each write, verifies copied-back shared buffer,\n"
		"                           re-registers, and sends the next rkey to the client\n"
		"  --iters N               sync-proto iterations (default 1)\n"
		"  --bench                 suppress per-iteration hexdumps and print timing summary\n"
		"  --readback              client RDMA_READs remote MR after write\n",
		p, p, DEFAULT_PORT, DEFAULT_SIZE, DEFAULT_IB_PORT,
		DEFAULT_SHARED_PATH);
}

int main(int argc, char **argv)
{
	int is_server = 0;
	const char *peer_ip = NULL;
	int port = DEFAULT_PORT;
	size_t size = DEFAULT_SIZE;
	const char *dev_name = NULL;
	int ib_port = DEFAULT_IB_PORT;
	const char *shared_path = DEFAULT_SHARED_PATH;
	int use_malloc = 0;
	int readback = 0;
	int server_flush_before_verify = 0;
	int server_dereg_before_verify = 0;
	int sync_proto = 0;
	int bench = 0;
	unsigned int iters = 1;
	int poll_ms = 0;
	int outbound_probe = 0;
	int inspect_cq = 0;
	int sync_data = 0;
	int cas_test = 0;
	unsigned int bw_writes = 0;
	unsigned int bw_batch = 1;
	int reverse_roles = 0;

	static const struct option long_opts[] = {
		{ "server", no_argument, 0, 'S' },
		{ "client", required_argument, 0, 'C' },
		{ "port", required_argument, 0, 'p' },
		{ "size", required_argument, 0, 's' },
		{ "device", required_argument, 0, 'd' },
		{ "ib-port", required_argument, 0, 'P' },
		{ "shared-path", required_argument, 0, 'M' },
		{ "malloc", no_argument, 0, 'm' },
		{ "readback", no_argument, 0, 1000 },
		{ "server-flush-before-verify", no_argument, 0, 1001 },
		{ "server-dereg-before-verify", no_argument, 0, 1002 },
		{ "sync-proto", no_argument, 0, 1003 },
		{ "iters", required_argument, 0, 1004 },
		{ "bench", no_argument, 0, 1005 },
		{ "poll-ms", required_argument, 0, 1006 },
		{ "outbound-probe", no_argument, 0, 1007 },
		{ "inspect-cq", no_argument, 0, 1008 },
		{ "sync-data", no_argument, 0, 1009 },
		{ "cas", no_argument, 0, 1010 },
		{ "bw", required_argument, 0, 1011 },
		{ "bw-batch", required_argument, 0, 1012 },
		{ "cq", required_argument, 0, 1013 },
		{ "reverse-roles", no_argument, 0, 1014 },
		{ "help", no_argument, 0, 'h' },
		{ 0, 0, 0, 0 },
	};
	int opt;
	while ((opt = getopt_long(argc, argv, "SC:p:s:d:P:M:mh", long_opts,
				  NULL)) != -1) {
		switch (opt) {
		case 'S': is_server = 1; break;
		case 'C': peer_ip = optarg; break;
		case 'p': port = atoi(optarg); break;
		case 's': size = strtoul(optarg, NULL, 0); break;
		case 'd': dev_name = optarg; break;
		case 'P': ib_port = atoi(optarg); break;
		case 'M': shared_path = optarg; break;
		case 'm': use_malloc = 1; break;
		case 1000: readback = 1; break;
		case 1001: server_flush_before_verify = 1; break;
		case 1002: server_dereg_before_verify = 1; break;
		case 1003: sync_proto = 1; break;
		case 1004:
			iters = strtoul(optarg, NULL, 0);
			if (iters == 0)
				iters = 1;
			break;
		case 1005: bench = 1; break;
		case 1006: poll_ms = atoi(optarg); break;
		case 1007: outbound_probe = 1; break;
		case 1008: inspect_cq = 1; break;
		case 1009: sync_data = 1; break;
		case 1010: cas_test = 1; break;
		case 1011: bw_writes = strtoul(optarg, NULL, 0); break;
		case 1012: bw_batch = strtoul(optarg, NULL, 0); break;
		case 1013:
			cq_entries = atoi(optarg);
			if (cq_entries < 64)
				cq_entries = 64;
			break;
		case 1014: reverse_roles = 1; break;
		case 'h':
		default: usage(argv[0]); return opt == 'h' ? 0 : 1;
		}
	}
	if ((!is_server && !peer_ip) || (is_server && peer_ip)) {
		usage(argv[0]);
		return 1;
	}

	int dev_fd = -1;
	void *buf = alloc_buffer(size, use_malloc ? NULL : shared_path,
				 &dev_fd);
	if (!buf)
		return 2;
	fprintf(stderr, "[%s] buffer @ %p (%zu bytes, %s)\n",
		is_server ? "server" : "client", buf, size,
		use_malloc ? "malloc" : shared_path);

	/* mn-to-sev (--reverse-roles): keep the TCP bootstrap direction (the SNP
	 * guest can only dial OUT through slirp NAT) but swap the RDMA roles —
	 * the TCP listener (MN/genie) becomes the one-sided initiator and the
	 * TCP connector (guest) becomes the passive MR target. */
	int rdma_initiator = reverse_roles ? is_server : !is_server;

	if (reverse_roles)
		fprintf(stderr, "[%s] reverse-roles: this side is the RDMA %s\n",
			is_server ? "server" : "client",
			rdma_initiator ? "INITIATOR" : "TARGET");

	if (!rdma_initiator) {
		memset(buf, 0xa5, size);
		flush_cpu_cache(buf, size);
	} else {
		fill_pattern(buf, size, 0);
	}

	struct rdma_ctx r = { .dev_fd = dev_fd };
	if (setup_qp(&r, dev_name, ib_port, buf, size))
		return 3;

	struct conn_info local = {
		.vaddr = (uint64_t)(uintptr_t)buf,
		.rkey = r.mr->rkey,
		.qpn = r.qp->qp_num,
		.psn = r.local_psn,
		.lid = r.local_lid,
		.pad = 0,
	};
	fprintf(stderr,
		"[%s] local : lid=0x%04x qpn=0x%06x psn=0x%06x rkey=0x%08x vaddr=0x%016lx\n",
		is_server ? "server" : "client", local.lid, local.qpn,
		local.psn, local.rkey, local.vaddr);

	int sock = is_server ? tcp_listen_accept(port) :
				     tcp_connect(peer_ip, port);
	if (sock < 0)
		return 4;

	struct conn_info remote;
	if (write_full(sock, &local, sizeof(local)) ||
	    read_full(sock, &remote, sizeof(remote))) {
		perror("conn_info exchange");
		return 5;
	}
	fprintf(stderr,
		"[%s] remote: lid=0x%04x qpn=0x%06x psn=0x%06x rkey=0x%08x vaddr=0x%016lx\n",
		is_server ? "server" : "client", remote.lid, remote.qpn,
		remote.psn, remote.rkey, remote.vaddr);

	if (qp_to_rtr_rts(&r, &remote, ib_port))
		return 6;

	/* --- raw RDMA-WRITE bandwidth mode (--bw N) -------------------------
	 * Measures true one-sided WRITE throughput: the client keeps the send
	 * queue full with `depth` signaled RDMA_WRITEs of `size` and times the
	 * whole burst; the server is entirely passive (holds its MR, waits for a
	 * one-byte "done"). No per-iter TCP round-trip, no verify — so the number
	 * is the NIC's WRITE bandwidth (incl. the SEV completion-interrupt tax on
	 * the client), not a synchronised protocol rate. One MR reused for all
	 * writes ⇒ no swiotlb-slot churn. */
	if (bw_writes) {
		if (!rdma_initiator) {
			fprintf(stderr, "[server] BW mode: holding MR, waiting for client write burst...\n");
			char done;
			if (read_full(sock, &done, 1))
				return 7;
			fprintf(stderr, "[server] BW: client signaled done (%u writes received).\n", bw_writes);
			return 0;
		}
		/* Pre-arm sequencing: the CQ is armed BEFORE each post cycle, so a
		 * completion — however fast — is written while armed, raises the
		 * completion interrupt, and the patched kernel (mlx5_ib_cq_comp)
		 * syncs the CQ bounce before the event wakes us. The old loop
		 * posted first and armed inside poll_cqe(), leaving exactly the
		 * race window problem.md §3 describes.
		 * --bw-batch K posts K-1 unsignaled WRITEs + 1 signaled sentinel
		 * per armed cycle; RC SQ ordering makes the sentinel's completion
		 * imply all earlier WRITEs completed (fewer CQEs, same guarantee).
		 * One WR per ibv_post_send call so each WQE is BlueFlame-copied to
		 * the HCA (no WQE fetch from the SWIOTLB-bounced SQ buffer). */
		if (bw_batch < 1)
			bw_batch = 1;
		if (bw_batch > 128)
			bw_batch = 128; /* SQ max_send_wr; slots recycle at the sentinel CQE */
		struct ibv_sge sge = { .addr = (uint64_t)(uintptr_t)buf, .length = size, .lkey = r.mr->lkey };
		struct ibv_send_wr wr = {
			.wr_id = 1, .sg_list = &sge, .num_sge = 1,
			.opcode = IBV_WR_RDMA_WRITE, .send_flags = IBV_SEND_SIGNALED,
			.wr.rdma = { .remote_addr = remote.vaddr, .rkey = remote.rkey },
		};
		struct ibv_send_wr *bad = NULL;
		struct ibv_wc wc;
		unsigned int done_cnt = 0;
		unsigned long long irq0 = mlx5_irq_total();
		fprintf(stderr, "[client] BW: %u RDMA_WRITEs x %zu B, batch=%u (pre-arm + sentinel) ...\n",
			bw_writes, size, bw_batch);
		unsigned long long t0 = now_ns();
		while (done_cnt < bw_writes) {
			unsigned int k = bw_writes - done_cnt;
			unsigned int i;

			if (k > bw_batch)
				k = bw_batch;
			if (arm_cq(&r)) { perror("bw arm_cq"); return 50; }
			for (i = 0; i < k; i++) {
				wr.send_flags = (i == k - 1) ? IBV_SEND_SIGNALED : 0;
				if (ibv_post_send(r.qp, &wr, &bad)) { perror("bw post_send"); return 50; }
			}
			int n = wait_armed_cqe(&r, &wc, poll_ms ? poll_ms : 10000);
			if (n != 1) {
				fprintf(stderr, "[client] BW: completion timeout at %u/%u (batch=%u)\n",
					done_cnt, bw_writes, k);
				bw_stall_diag(&r, irq0);
				return 51;
			}
			if (wc.status != IBV_WC_SUCCESS) { fprintf(stderr, "[client] BW: WR failed status=%d (%s) at %u\n", wc.status, ibv_wc_status_str(wc.status), done_cnt); return 52; }
			done_cnt += k;
		}
		unsigned long long dt = now_ns() - t0;
		double sec = (double)dt / 1e9;
		double bytes = (double)size * bw_writes;
		fprintf(stderr,
			"[client] BW RESULT: %u RDMA_WRITEs x %zu B = %.1f MiB in %.4f s => %.3f Gbit/s (%.1f MiB/s), batch=%u\n",
			bw_writes, size, bytes / (1024.0 * 1024.0), sec,
			bytes * 8.0 / 1e9 / sec, bytes / (1024.0 * 1024.0) / sec, bw_batch);
		char done = 'D';
		if (write_full(sock, &done, 1))
			return 53;
		return 0;
	}

	char sync;
	if (!rdma_initiator) {
		unsigned int loops = sync_proto ? iters : 1;
		struct bench_stats dereg_stats = { 0 };
		struct bench_stats verify_stats = { 0 };
		struct bench_stats ack_stats = { 0 };
		struct bench_stats prep_stats = { 0 };
		unsigned long long total_t0 = now_ns();

		if (sync_proto)
			fprintf(stderr,
				"[server] QP up. sync-proto iterations=%u\n",
				loops);
		else
				fprintf(stderr,
					"[server] QP up. waiting for client signal...\n");
		for (unsigned int iter = 0; iter < loops; iter++) {
			if (sync_proto && !bench)
				fprintf(stderr,
					"[server] iter %u/%u waiting for client signal...\n",
					iter + 1, loops);
			if (read_full(sock, &sync, 1))
				return 7;
			unsigned long long ack_t0 = now_ns();

			if (server_dereg_before_verify || sync_proto) {
				if (sync_proto && !bench)
					fprintf(stderr,
						"[server] deregistering MR before verify iter=%u\n",
						iter);
				else if (!sync_proto)
					fprintf(stderr,
						"[server] deregistering MR before verify\n");
				unsigned long long t0 = now_ns();
				if (ibv_dereg_mr(r.mr)) {
					perror("ibv_dereg_mr");
					return 12;
				}
				stats_add(&dereg_stats, now_ns() - t0);
				r.mr = NULL;
			}
			if (server_flush_before_verify) {
				fprintf(stderr,
					"[server] flushing CPU cache before verify\n");
				flush_cpu_cache(buf, size);
			}
			if (!bench) {
				if (sync_proto)
					fprintf(stderr,
						"[server] client signaled write done iter=%u. first 64 bytes:\n  ",
						iter);
				else
					fprintf(stderr,
						"[server] client signaled write done. first 64 bytes:\n  ");
				dump_first64(buf);
			}
			size_t first_bad = 0;
			unsigned long long verify_t0 = now_ns();
			size_t mismatches = count_pattern_mismatches(
				buf, size, iter, &first_bad);
			stats_add(&verify_stats, now_ns() - verify_t0);
			if (mismatches == 0) {
				if (sync_proto && !bench)
					fprintf(stderr,
						"[server] SYNC PASS iter=%u: full %zu byte pattern verified.\n",
						iter, size);
				else if (!sync_proto)
					fprintf(stderr,
						"[server] PASS: full %zu byte pattern verified.\n",
						size);
			} else {
				if (sync_proto)
					fprintf(stderr,
						"[server] SYNC FAIL iter=%u: %zu mismatches (first at byte %zu, got 0x%02x expected 0x%02x).\n",
						iter, mismatches, first_bad,
						((unsigned char *)buf)[first_bad],
						pattern_byte(first_bad, iter));
				else
					fprintf(stderr,
						"[server] FAIL: %zu mismatches (first at byte %zu, got 0x%02x expected 0x%02x).\n",
						mismatches, first_bad,
						((unsigned char *)buf)[first_bad],
						pattern_byte(first_bad, iter));
			}
			char ack = sync_proto ? (mismatches == 0 ? 'P' : 'F') : 'X';
			if (write_full(sock, &ack, 1))
				return 13;
			stats_add(&ack_stats, now_ns() - ack_t0);
			if (sync_proto && mismatches)
				return 19;

			if (sync_proto && iter + 1 < loops) {
				unsigned long long prep_t0 = now_ns();
				memset(buf, 0xa5, size);
				flush_cpu_cache(buf, size);
				if (register_mr(&r, buf, size))
					return 14;
				struct mr_info mr = make_mr_info(&r);
				if (!bench)
					fprintf(stderr,
						"[server] iter %u prepared next MR rkey=0x%08x vaddr=0x%016lx\n",
						iter + 2, mr.rkey, mr.vaddr);
				if (write_full(sock, &mr, sizeof(mr)))
					return 15;
				stats_add(&prep_stats, now_ns() - prep_t0);
			}
		}
		if (sync_proto) {
			fprintf(stderr,
				"[server] sync-proto complete: %u iterations.\n",
				loops);
			if (bench) {
				bench_summary("server", size, loops,
					      now_ns() - total_t0);
				stats_print("server", "dereg_copyback_us",
					    &dereg_stats);
				stats_print("server", "verify_us", &verify_stats);
				stats_print("server", "signal_to_ack_us",
					    &ack_stats);
				stats_print("server", "reset_rereg_send_mr_us",
					    &prep_stats);
			}
		}
	} else if (cas_test) {
		/* Verify 64-bit atomic CAS in-guest (the CN uses it for the row
		 * header). Opcode-agnostic w.r.t. the SEV fix: the completion syncs
		 * via the patched cq_comp interrupt path, and the returned original
		 * 8 bytes (DMA'd into buf) sync via §14.1b dereg. */
		struct ibv_send_wr *bad = NULL;
		struct ibv_wc wc;
		uint64_t setup = 0xAAAA0000AAAA0000ULL, swapv = 0xBBBB1111BBBB1111ULL;
		/* 1) seed remote[0] = setup via an 8-byte RDMA_WRITE */
		*(uint64_t *)buf = setup;
		struct ibv_sge wsge = { .addr = (uint64_t)(uintptr_t)buf, .length = 8, .lkey = r.mr->lkey };
		struct ibv_send_wr wwr = { .wr_id = 1, .sg_list = &wsge, .num_sge = 1,
			.opcode = IBV_WR_RDMA_WRITE, .send_flags = IBV_SEND_SIGNALED,
			.wr.rdma = { .remote_addr = remote.vaddr, .rkey = remote.rkey } };
		if (ibv_post_send(r.qp, &wwr, &bad) || poll_cqe(&r, &wc, poll_ms) != 1) {
			fprintf(stderr, "[client] CAS seed WRITE failed/timeout\n"); return 40;
		}
		/* 2) CAS(remote[0], compare=setup, swap=swapv); original -> buf[8..16) */
		struct ibv_sge asge = { .addr = (uint64_t)(uintptr_t)buf + 8, .length = 8, .lkey = r.mr->lkey };
		struct ibv_send_wr awr = { .wr_id = 2, .sg_list = &asge, .num_sge = 1,
			.opcode = IBV_WR_ATOMIC_CMP_AND_SWP, .send_flags = IBV_SEND_SIGNALED,
			.wr.atomic = { .remote_addr = remote.vaddr, .rkey = remote.rkey,
				       .compare_add = setup, .swap = swapv } };
		if (ibv_post_send(r.qp, &awr, &bad)) { fprintf(stderr, "[client] CAS post failed\n"); return 41; }
		int cn = poll_cqe(&r, &wc, poll_ms);
		if (cn != 1) { fprintf(stderr, "[client] CAS CQE not visible (rc=%d)\n", cn); return 42; }
		if (wc.status != IBV_WC_SUCCESS) { fprintf(stderr, "[client] CAS status=%s\n", ibv_wc_status_str(wc.status)); return 43; }
		ibv_dereg_mr(r.mr); r.mr = NULL; /* §14.1b: sync the returned original into buf */
		uint64_t got = *(uint64_t *)(buf + 8);
		fprintf(stderr, "[client] CAS CQE VISIBLE (SUCCESS); returned original=0x%016lx expected=0x%016lx\n", got, setup);
		if (got == setup) { fprintf(stderr, "[client] CAS PASS: completion visible + atomic original correct\n"); return 0; }
		fprintf(stderr, "[client] CAS FAIL: original mismatch\n"); return 44;
	} else {
		unsigned int loops = sync_proto ? iters : 1;
		struct ibv_send_wr *bad = NULL;
		struct ibv_wc wc;
		struct bench_stats next_mr_stats = { 0 };
		struct bench_stats prep_stats = { 0 };
		struct bench_stats write_cqe_stats = { 0 };
		struct bench_stats readback_stats = { 0 };
		struct bench_stats ack_stats = { 0 };
		unsigned long long total_t0 = now_ns();
		int n;

		for (unsigned int iter = 0; iter < loops; iter++) {
			if (sync_proto && iter > 0) {
				struct mr_info mr;

				unsigned long long t0 = now_ns();
				if (read_full(sock, &mr, sizeof(mr)))
					return 16;
				stats_add(&next_mr_stats, now_ns() - t0);
				remote.vaddr = mr.vaddr;
				remote.rkey = mr.rkey;
				if (!bench)
					fprintf(stderr,
						"[client] iter %u received next remote MR rkey=0x%08x vaddr=0x%016lx\n",
						iter + 1, remote.rkey, remote.vaddr);
			}
			unsigned long long prep_t0 = now_ns();
			fill_pattern(buf, size, iter);
			stats_add(&prep_stats, now_ns() - prep_t0);
			struct ibv_sge sge = {
				.addr = (uint64_t)(uintptr_t)buf,
				.length = size,
				.lkey = r.mr->lkey,
			};
			struct ibv_send_wr wr = {
				.wr_id = 1,
				.sg_list = &sge,
				.num_sge = 1,
				.opcode = IBV_WR_RDMA_WRITE,
				.send_flags = IBV_SEND_SIGNALED,
				.wr.rdma.remote_addr = remote.vaddr,
				.wr.rdma.rkey = remote.rkey,
			};
			if (sync_proto && !bench)
				fprintf(stderr,
					"[client] posting RDMA_WRITE %zu bytes to remote iter=%u\n",
					size, iter);
			else if (!sync_proto)
				fprintf(stderr,
					"[client] posting RDMA_WRITE %zu bytes to remote\n",
					size);
			unsigned long long ack_t0 = now_ns();
			unsigned long long write_t0 = ack_t0;
			if (ibv_post_send(r.qp, &wr, &bad)) {
				perror("ibv_post_send");
				return 8;
			}
			if (outbound_probe) {
				/* Decompose the WRITE: (1) tell the server to verify
				 * regardless of whether we can see our own completion —
				 * its log's PASS/FAIL is the OUTBOUND verdict (did the
				 * bytes actually land in remote memory); (2) then bounded-
				 * poll our CQ to report completion VISIBILITY separately. */
				usleep(100000); /* let the one-sided WRITE land remotely */
				if (write_full(sock, "X", 1))
					return 17;
				if (read_full(sock, &sync, 1)) /* drain server ack */
					return 18;
				fprintf(stderr,
					"[client] outbound signaled — server verified (its log PASS/FAIL = did the WRITE reach remote memory)\n");
				if (inspect_cq) {
					/* The WRITE has completed at the HCA (server verified
					 * the bytes). Read the CQ buffer the CPU sees, via
					 * mlx5dv, and check whether the HCA-written CQE is
					 * actually present there. All-zero => the CQE the device
					 * wrote is NOT in the CPU-visible CQ page (bounce/encrypt
					 * mismatch → CQ must be relocated to shared memory).
					 * Non-zero => CQE is visible in memory (failure is
					 * elsewhere, e.g. dbrec/UAR). */
					struct mlx5dv_cq dvcq = { 0 };
					struct mlx5dv_obj obj = { 0 };
					obj.cq.in = r.cq;
					obj.cq.out = &dvcq;
					int rc = mlx5dv_init_obj(&obj, MLX5DV_OBJ_CQ);
					if (rc) {
						fprintf(stderr,
							"[client] inspect-cq: mlx5dv_init_obj failed rc=%d\n", rc);
					} else {
						usleep(50000);
						unsigned char *cqe0 = (unsigned char *)dvcq.buf;
						size_t cs = dvcq.cqe_size ? dvcq.cqe_size : 64;
						size_t nz = 0;
						for (size_t b = 0; b < cs; b++)
							if (cqe0[b]) nz++;
						fprintf(stderr,
							"[client] inspect-cq: cqn=%u cqe_cnt=%u cqe_size=%zu buf=%p — CPU-visible CQE[0]: %zu/%zu non-zero bytes; op_own(last)=0x%02x\n",
							dvcq.cqn, dvcq.cqe_cnt, cs, dvcq.buf, nz, cs, cqe0[cs - 1]);
						fprintf(stderr, "[client] inspect-cq: CQE[0] first 32 bytes: ");
						for (size_t b = 0; b < 32 && b < cs; b++)
							fprintf(stderr, "%02x ", cqe0[b]);
						/* A valid mlx5 CQE has opcode (op_own>>4) != 0xf.
						 * 0xf0 == MLX5_CQE_INVALID<<4 == the libmlx5 init
						 * marker: the HCA never updated this CPU-visible slot. */
						int op = cqe0[cs - 1] >> 4;
						fprintf(stderr, "\n[client] inspect-cq VERDICT: %s\n",
							op == 0xf ? "CQE slot still MLX5_CQE_INVALID (0xf0) — HCA did NOT update the CPU-visible CQ memory → CQ ring is not device↔CPU coherent under SEV → relocate CQ buffer to shared/decrypted memory"
								: "CQE slot updated by HCA (valid opcode) — poll failure is NOT a CQ-location problem");
					}
				}
				n = poll_cqe(&r, &wc, poll_ms);
				if (n == 0)
					fprintf(stderr,
						"[client] WRITE CQE: NOT VISIBLE after %d ms — completion ring never synced to CPU\n",
						poll_ms);
				else if (n > 0 && wc.status == IBV_WC_SUCCESS)
					fprintf(stderr,
						"[client] WRITE CQE: VISIBLE (status SUCCESS)\n");
				else
					fprintf(stderr,
						"[client] WRITE CQE: poll n=%d status=%d (%s)\n",
						n, wc.status, ibv_wc_status_str(wc.status));
				return n == 0 ? 30 : 0;
			}
			n = poll_cqe(&r, &wc, poll_ms);
			if (n == 0) {
				fprintf(stderr,
					"[client] RDMA_WRITE CQE TIMEOUT after %d ms — completion never became CPU-visible (WRITE may still have reached the remote; ask the server)\n",
					poll_ms);
				return 30;
			}
			if (n < 0 || wc.status != IBV_WC_SUCCESS) {
				fprintf(stderr,
					"[client] RDMA_WRITE FAILED: status=%d (%s)\n",
					wc.status, ibv_wc_status_str(wc.status));
				return 9;
			}
			stats_add(&write_cqe_stats, now_ns() - write_t0);
			if (!bench)
				fprintf(stderr,
					"[client] RDMA_WRITE completed (status=%d, opcode=%d)\n",
					wc.status, wc.opcode);
			if (readback) {
				memset(buf, 0xcc, size);
				struct ibv_sge read_sge = {
					.addr = (uint64_t)(uintptr_t)buf,
					.length = size,
					.lkey = r.mr->lkey,
				};
				struct ibv_send_wr read_wr = {
					.wr_id = 2,
					.sg_list = &read_sge,
					.num_sge = 1,
					.opcode = IBV_WR_RDMA_READ,
					.send_flags = IBV_SEND_SIGNALED,
					.wr.rdma.remote_addr = remote.vaddr,
					.wr.rdma.rkey = remote.rkey,
				};
				if (sync_proto && !bench)
					fprintf(stderr,
						"[client] posting RDMA_READ %zu bytes from remote iter=%u\n",
						size, iter);
				else if (!sync_proto)
					fprintf(stderr,
						"[client] posting RDMA_READ %zu bytes from remote\n",
						size);
				unsigned long long read_t0 = now_ns();
				if (ibv_post_send(r.qp, &read_wr, &bad)) {
					perror("ibv_post_send(read)");
					return 10;
				}
				n = poll_cqe(&r, &wc, poll_ms);
				if (n == 0) {
					fprintf(stderr,
						"[client] RDMA_READ CQE TIMEOUT after %d ms — completion never became CPU-visible\n",
						poll_ms);
					return 31;
				}
				if (n < 0 || wc.status != IBV_WC_SUCCESS) {
					fprintf(stderr,
						"[client] RDMA_READ FAILED: status=%d (%s)\n",
						wc.status, ibv_wc_status_str(wc.status));
					return 11;
				}
				stats_add(&readback_stats, now_ns() - read_t0);
				if (sync_data) {
					/* SEV-SNP: the READ response DMA'd into buf through an
					 * unsynced SWIOTLB bounce; deregistering the MR does the
					 * dma_unmap that copies the bounce back into buf (§14.1b).
					 * buf is plain malloc, still valid after dereg. */
					ibv_dereg_mr(r.mr);
					r.mr = NULL;
				}
				if (!bench) {
					fprintf(stderr,
						"[client] RDMA_READ completed (status=%d, opcode=%d). first 64 bytes:\n  ",
						wc.status, wc.opcode);
					dump_first64(buf);
				}
				size_t first_bad = 0;
				size_t mismatches = count_pattern_mismatches(
					buf, size, iter, &first_bad);
				if (mismatches == 0) {
					if (sync_proto && !bench)
						fprintf(stderr,
							"[client] READBACK PASS iter=%u: full %zu byte pattern visible to NIC.\n",
							iter, size);
					else if (!sync_proto)
						fprintf(stderr,
							"[client] READBACK PASS: full %zu byte pattern visible to NIC.\n",
							size);
				} else {
					if (sync_proto)
						fprintf(stderr,
							"[client] READBACK FAIL iter=%u: %zu mismatches (first at byte %zu, got 0x%02x expected 0x%02x).\n",
							iter, mismatches, first_bad,
							((unsigned char *)buf)[first_bad],
							pattern_byte(first_bad, iter));
					else
						fprintf(stderr,
							"[client] READBACK FAIL: %zu mismatches (first at byte %zu, got 0x%02x expected 0x%02x).\n",
							mismatches, first_bad,
							((unsigned char *)buf)[first_bad],
							pattern_byte(first_bad, iter));
				}
			}
			if (write_full(sock, "X", 1))
				return 17;
			if (read_full(sock, &sync, 1))
				return 18;
			stats_add(&ack_stats, now_ns() - ack_t0);
			if (sync_proto && sync != 'P') {
				fprintf(stderr,
					"[client] server reported sync-proto failure at iter=%u (ack=%c).\n",
					iter, sync);
				return 20;
			}
			if (sync_proto && !bench)
				fprintf(stderr,
					"[client] server acknowledged iter=%u.\n",
					iter);
			else if (!sync_proto)
				fprintf(stderr,
					"[client] server acknowledged. done.\n");
		}
		if (sync_proto) {
			fprintf(stderr,
				"[client] sync-proto complete: %u iterations.\n",
				loops);
			if (bench) {
				bench_summary("client", size, loops,
					      now_ns() - total_t0);
				stats_print("client", "next_mr_wait_us",
					    &next_mr_stats);
				stats_print("client", "source_fill_us", &prep_stats);
				stats_print("client", "rdma_write_cqe_us",
					    &write_cqe_stats);
				stats_print("client", "rdma_readback_cqe_us",
					    &readback_stats);
				stats_print("client", "write_to_server_ack_us",
					    &ack_stats);
			}
		}
	}

	close(sock);
	if (r.mr)
		ibv_dereg_mr(r.mr);
	ibv_destroy_qp(r.qp);
	ibv_destroy_cq(r.cq);
	ibv_dealloc_pd(r.pd);
	ibv_close_device(r.ctx);
	if (use_malloc)
		free(buf);
	else {
		munmap(buf, size);
		if (dev_fd >= 0)
			close(dev_fd);
	}
	return 0;
}

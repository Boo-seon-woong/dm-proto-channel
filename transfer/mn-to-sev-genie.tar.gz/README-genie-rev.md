# mn-to-sev reverse-roles round — genie(MN) = RDMA initiator

Build (same as before):
    gcc -O2 snp_rdma_test.c -o snp_rdma_test_rev -libverbs -lmlx5

What changed vs the reviewed p2 source (full diff-able source enclosed):
  * pre-arm sequencing + --bw-batch + --cq + stall diag (sev-to-mn round, guest-side aids;
    inert on non-TEE genie)
  * NEW --reverse-roles: keeps TCP direction (guest dials out to genie) but swaps RDMA
    roles — TCP listener (genie) runs the one-sided WRITE/READ initiator logic, TCP
    connector (guest) is the passive MR target. No kernel/lib changes needed on genie.

Runs (one server process per run; guest connects right after your "up" notice):
  # 1. correctness (WRITE + READBACK verify on genie side; guest verifies too)
  ./snp_rdma_test_rev --server --malloc -d ibp23s0 -p 18515 --reverse-roles --readback
  # 2. WRITE bandwidth into the SEV guest (deep batch)
  ./snp_rdma_test_rev --server --malloc -d ibp23s0 -p 18515 --reverse-roles --bw 4000 --bw-batch 64
  # 3. repeat run 2 (soak)
Loop form is fine too (auto re-listen):
  while true; do ./snp_rdma_test_rev --server --malloc -d ibp23s0 -p 18515 --reverse-roles --bw 4000 --bw-batch 64; done

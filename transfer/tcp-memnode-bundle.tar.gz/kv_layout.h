/* Shared item-store layout for the disaggregated memcached store. Only the compute
 * node interprets this; the memory node just holds region = nslots * KV_SLOT bytes. */
#ifndef KV_LAYOUT_H
#define KV_LAYOUT_H
#include <stdint.h>
#include <string.h>

#define KV_SLOT   1024                 /* fixed slot size (bytes) */
#define KV_KMAX   250                  /* memcached max key length */
#define KV_HDR    (4 + KV_KMAX)        /* state,klen,vlen,flags(as below) + key */
#define KV_VMAX   (KV_SLOT - 8 - KV_KMAX)  /* value capacity per slot */

/* slot bytes: [0]=state(0 empty/1 occupied) [1]=klen [2..3]=vlen(LE) [4..7]=flags(LE)
 * [8..8+KMAX)=key  [8+KMAX..)=value */
static inline uint8_t  slot_state(const char *s){ return (uint8_t)s[0]; }
static inline uint8_t  slot_klen(const char *s){ return (uint8_t)s[1]; }
static inline uint16_t slot_vlen(const char *s){ return (uint8_t)s[2] | ((uint16_t)(uint8_t)s[3] << 8); }
static inline uint32_t slot_flags(const char *s){ uint32_t f; memcpy(&f, s+4, 4); return f; }
static inline const char *slot_key(const char *s){ return s + 8; }
static inline const char *slot_val(const char *s){ return s + 8 + KV_KMAX; }

static inline void slot_build(char *s, const char *k, uint8_t klen,
			      const char *v, uint16_t vlen, uint32_t flags){
	s[0] = 1; s[1] = klen; s[2] = vlen & 0xff; s[3] = (vlen >> 8) & 0xff;
	memcpy(s+4, &flags, 4);
	memcpy(s+8, k, klen);
	if (vlen) memcpy(s+8+KV_KMAX, v, vlen);
}
static inline int slot_key_matches(const char *s, const char *k, uint8_t klen){
	return slot_state(s) == 1 && slot_klen(s) == klen && !memcmp(slot_key(s), k, klen);
}

/* FNV-1a 64-bit hash → slot index. */
static inline uint64_t kv_hash(const char *k, size_t n){
	uint64_t h = 1469598103934665603ULL;
	for (size_t i = 0; i < n; i++){ h ^= (uint8_t)k[i]; h *= 1099511628211ULL; }
	return h;
}
#endif

# memnode bundle v3 (self-healing) — memcached-rdma memory node (genie)
run-memnode.sh is now a RESPAWN LOOP: memnode exits when the compute detaches (TCP EOF), the loop
restarts it with a fresh QP → the compute can reconnect WITHOUT a manual memnode restart.
  chmod +x run-memnode.sh memnode ; ./run-memnode.sh ibp23s0 18600 262144
256 MiB store. Firewall 18600 from 10.20.18.58. Keeps running across compute restarts.

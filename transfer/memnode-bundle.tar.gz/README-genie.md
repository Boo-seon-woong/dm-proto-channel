# memnode bundle v2 (robust) — memcached-rdma memory node (genie, non-TEE)
Now SKIPS stray/garbage TCP connects (won't die on a probe). Run:
  chmod +x run-memnode.sh memnode ; ./run-memnode.sh ibp23s0 18600 262144
262144 slots x 1KiB = 256 MiB. Firewall 18600 from 10.20.18.58. Ctrl-C to stop.

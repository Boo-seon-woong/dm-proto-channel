# memnode bundle — memcached-rdma memory node (run on genie, non-TEE)

Passive one-sided RDMA target holding the item store. No data-path CPU logic.
```
chmod +x run-memnode.sh memnode
./run-memnode.sh ibp23s0 18600 262144      # dev, tcp_port, nslots(=region/1KiB)
# or rebuild from source if the prebuilt won't run:  make ; then run
```
262144 slots x 1KiB = 256 MiB region. Firewall: open inbound TCP 18600 from ariel (10.20.18.58)
for the QP bootstrap (RDMA itself is over the IB fabric). Ctrl-C to stop.

#!/usr/bin/env bash
# memory node on genie (non-TEE). usage: run-memnode.sh [dev] [tcp_port] [nslots]
set -u
DEV=${1:-ibp23s0}; PORT=${2:-18600}; NSLOTS=${3:-1048576}
exec ./memnode -d "$DEV" -p "$PORT" -n "$NSLOTS"

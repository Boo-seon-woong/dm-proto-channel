# mn-to-sev reverse-roles round v2 — genie(MN) = RDMA initiator (adds --bw-read)

Build:
    gcc -O2 snp_rdma_test.c -o snp_rdma_test_rev -libverbs -lmlx5

Delta vs the previous bundle (584e4510): adds **--bw-read** (initiator issues an RDMA_READ
burst instead of WRITE — measures MN-reads-guest bandwidth) and raises RC max_rd_atomic
1->16 so READs can pipeline. --reverse-roles unchanged (TCP listener = one-sided initiator).
No kernel/lib changes on genie.

Runs (guest connects right after your "up" notice, no probe; loop form auto re-listens):
  # 1. correctness (already PASSed):
  ./snp_rdma_test_rev --server --malloc -d ibp23s0 -p 18515 --reverse-roles --readback
  # 2. WRITE bandwidth MN->guest (done: ~194-195 Gbit/s):
  ./snp_rdma_test_rev --server --malloc -d ibp23s0 -p 18515 --reverse-roles --bw 4000 --bw-batch 64
  # 3. READ bandwidth (MN reads guest) — NEW, needs this bundle:
  ./snp_rdma_test_rev --server --malloc -d ibp23s0 -p 18515 --reverse-roles --bw 4000 --bw-read --bw-batch 64

#!/usr/bin/env bash
# Build the RDMA test (same binary for --server and --client). Both sides.
set -e
cd "$(dirname "$0")"
gcc -O2 snp_rdma_test.c -o snp_rdma_test -libverbs -lmlx5
echo "built: $(pwd)/snp_rdma_test"

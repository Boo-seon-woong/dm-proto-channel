#!/usr/bin/env bash
# genie (non-TEE) RDMA responder.  Usage: ./genie_server.sh [ibdev] [port]
set -eu
cd "$(dirname "$0")"
DEV="${1:-$(ibv_devices 2>/dev/null | awk 'NR==3{print $1}')}"
PORT="${2:-18515}"
[ -x ./snp_rdma_test ] || gcc -O2 snp_rdma_test.c -o snp_rdma_test -libverbs -lmlx5
echo "== genie server (non-TEE, --malloc)  dev=$DEV port=$PORT =="
echo "   (keep running; verifies the pattern ariel's guest client WRITEs)"
exec ./snp_rdma_test --server --malloc -d "$DEV" -p "$PORT"

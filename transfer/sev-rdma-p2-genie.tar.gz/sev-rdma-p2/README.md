# prototype-2 — SEV↔non-TEE RDMA connectivity (isolated from the KVS)

A **standalone** check that one-sided RDMA WRITE + READ works from **inside an
AMD SEV-SNP guest (ariel)** to a **non-TEE peer (genie)**, decoupled from the
disaggregated-KVS prototype. One self-contained program, `snp_rdma_test.c`, runs
on both sides (`--server` / `--client`).

Two parties (no third host):

| role | host | mode |
|---|---|---|
| **client / initiator** | **ariel** SEV-SNP guest (VFIO ConnectX-7) | `--client <genie-ip> --readback` |
| **server / responder** | **genie** (non-TEE) | `--server --malloc` |

The client does an RDMA **WRITE** into the server's buffer, then a **READ**
(`--readback`) of it back — so it exercises both directions *and* the SEV-guest
completion path that the swiotlb fix targets.

## ⚠️ Hard dependency (the whole point of this test)

Inside an SEV-SNP guest, inbound RDMA DMA to userspace pages is force-bounced
through SWIOTLB and the bounce is **not** synced back on the kernel-bypass poll
path — so a **stock** guest kernel sees *no* completions and reads stale data
(the first attempt, 2026-07-03, failed exactly this way: `poll timeout`). The fix
is a patched **`mlx5_ib.ko`** (dma_sync in the completion interrupt) + the app
using **event-driven completion** (`snp_rdma_test` already does). So on the guest
you MUST load the shipped `mlx5_ib.ko` first, or this test fails by design.

`mlx5_ib.ko` here is built for guest kernel **6.16.0-snp-guest-038d61fd6422**
(`modinfo mlx5_ib.ko | grep vermagic`). Boot the guest on that kernel
(`guestctl.sh up` uses `--direct-kernel-boot` to pin it).

---

## A. genie side (non-TEE responder) — human-executable

```sh
# on genie, in this bundle's directory:
gcc -O2 snp_rdma_test.c -o snp_rdma_test -libverbs -lmlx5     # or: ./build.sh
ibv_devices                                                  # note your IB device, e.g. ibp23s0
./snp_rdma_test --server --malloc -d <your-ibdev> -p 18515
#   -> prints local LID/QPN/rkey, then "waiting for client…"
#   Keep it running; it verifies the pattern the client WROTE and exits PASS/FAIL.
```

- Non-TEE, so `--malloc` (ordinary heap) — no SNP buffer needed.
- Port 18515/TCP is only the control channel (LID/QPN/rkey exchange) over IPoIB;
  the data path is native IB. Make sure ariel can reach `genie:18515/tcp`
  (same firewall class as the MN ports).
- For a 3-iteration repeat use `--server --malloc --sync-proto --iters 3`.

## B. ariel side (SEV-SNP guest initiator) — human-executable

**B1. (ariel host) boot the guest + stage the files** — this GRABS the HCA
(`ibp193s0`) from the host into the guest, so nothing else on the host can use
RDMA while the guest is up:

```sh
~/2026/sev-rdma-p2/ariel_guest_up.sh          # boots guest, waits for ssh, scp's the 2 files in
```

**B2. (ariel guest) load the fix + run the client:**

> The stock cloud image has **no gcc** (and apt may be broken). `ariel_guest_up.sh`
> stages the **host-built `~/snp_rdma_test` binary** too — it's ABI-compatible with
> the guest's `libibverbs`/`libmlx5`, so just run it; no compiler needed.

```sh
ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -i ~/.ssh/snp_guest -p 2222 ubuntu@localhost
# ── inside the guest ──
sudo rmmod mlx5_ib && sudo insmod ~/mlx5_ib.ko     # load the swiotlb-fix module
lsmod | grep mlx5_ib                               # confirm loaded
ibv_devices                                        # guest sees the passed device, e.g. ibp1s0
~/snp_rdma_test --client 10.20.26.87 --readback --sync-data --malloc -d ibp1s0 -p 18515
#   expect: RDMA_WRITE completed, RDMA_READ completed, "READBACK PASS: full pattern visible".
```

- **`--sync-data` is REQUIRED** on the SEV client: it deregs the data MR after the
  READ (§14.1b) so the SWIOTLB bounce is copied back into the guest-private page.
  Drop it and the READBACK shows stale bytes (that's the swiotlb symptom itself —
  try it once to see the before/after).
- genie (non-TEE) does NOT bounce, so its server side needs no extra flag.
- Replace `10.20.26.87` / `ibp1s0` with genie's IP and the guest's device.

**B2-alt. genie-independent self-check (loopback, entirely inside the guest)** —
proves in-SEV RDMA works with no genie/firewall. Two shells in the guest:

```sh
# shell 1 (server; both endpoints are SEV here, so it also needs the dereg sync):
~/snp_rdma_test --server --malloc --server-dereg-before-verify -d ibp1s0 -p 18516
# shell 2 (client):
~/snp_rdma_test --client 127.0.0.1 --readback --sync-data --malloc -d ibp1s0 -p 18516
#   -> client "READBACK PASS" + server "PASS: full 4194304 byte pattern verified"  (confirmed 2026-07-06)
```

**B3. (ariel host) tear down** when done — returns the HCA to the host:

```sh
sudo ~/2026/sev/guestctl.sh down
```

## What PASS means

- **WRITE ok** = the server verified the exact byte pattern the guest client
  wrote into its buffer → guest→genie one-sided WRITE works through SWIOTLB.
- **READBACK PASS** = the guest client READ the server's buffer and *saw* the
  bytes (not stale) → the completion/read path is synced past the bounce (the fix
  works). This is the result that failed on a stock kernel.

## Provenance / honesty

- Originally validated 2026-07-03 (guest→genie, 3/3 READBACK PASS) — see
  `dm-prototype/sev-guest-patches/README.md`. This bundle isolates exactly that
  check so it can be re-run by hand, independent of the KVS.
- CAS: works against a real remote peer; a guest-*loopback* CAS-completion quirk
  is orthogonal to swiotlb (noted in the patch README). This test uses WRITE+READ.

## Files

| file | side | purpose |
|---|---|---|
| `snp_rdma_test.c` | both | the RDMA test (server & client in one binary) |
| `mlx5_ib.ko` | ariel guest | swiotlb completion-visibility fix (6.16-snp-guest) |
| `build.sh` | both | `gcc` one-liner |
| `genie_server.sh` | genie | build + run `--server` |
| `ariel_guest_up.sh` | ariel host | boot SNP guest + scp files in |
| `ariel_guest_client.sh` | ariel guest | load ko + build + run `--client` |

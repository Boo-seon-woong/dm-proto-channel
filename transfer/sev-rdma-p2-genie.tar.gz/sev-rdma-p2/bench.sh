#!/usr/bin/env bash
# prototype-2 bandwidth + RDMA-proof harness.
# Wraps `snp_rdma_test --sync-proto --bench` and samples the IB port DATA counters
# before/after — so one run gives BOTH (a) throughput and (b) proof the bytes
# crossed the InfiniBand fabric via RDMA (not TCP). IB counters are in 4-byte
# words, so bytes = delta * 4.  A TCP/IP fallback would leave these ~0.
# Usage:
#   genie (server): ./bench.sh server <ibdev> <port> <iters> [size_bytes]
#   guest (client): ./bench.sh client <peer-ip> <ibdev> <port> <iters> [size_bytes]
set -eu
BIN="${BIN:-}"
if [ -z "$BIN" ]; then
  for c in ./snp_rdma_test "$HOME/snp_rdma_test" "$(dirname "$0")/snp_rdma_test"; do
    [ -x "$c" ] && BIN="$c" && break
  done
fi
[ -x "$BIN" ] || { echo "snp_rdma_test binary not found (set BIN=...)"; exit 1; }
ctr() { cat "/sys/class/infiniband/$1/ports/1/counters/$2" 2>/dev/null || echo 0; }

role="${1:?role: server|client}"; shift
if [ "$role" = server ]; then
  DEV="$1"; PORT="$2"; ITERS="$3"; SIZE="${4:-4194304}"
  X0=$(ctr "$DEV" port_xmit_data); R0=$(ctr "$DEV" port_rcv_data)
  "$BIN" --server --malloc --sync-proto --iters "$ITERS" -s "$SIZE" -d "$DEV" -p "$PORT" --bench
  X1=$(ctr "$DEV" port_xmit_data); R1=$(ctr "$DEV" port_rcv_data)
  echo "[server] IB fabric bytes: port_rcv_data +$(( (R1-R0)*4 )) , port_xmit_data +$(( (X1-X0)*4 ))  (nonzero => data went over IB = RDMA)"
else
  PEER="$1"; DEV="$2"; PORT="$3"; ITERS="$4"; SIZE="${5:-4194304}"
  X0=$(ctr "$DEV" port_xmit_data); R0=$(ctr "$DEV" port_rcv_data)
  "$BIN" --client "$PEER" --malloc --sync-proto --iters "$ITERS" -s "$SIZE" -d "$DEV" -p "$PORT" --bench
  X1=$(ctr "$DEV" port_xmit_data); R1=$(ctr "$DEV" port_rcv_data)
  echo "[client] IB fabric bytes: port_xmit_data +$(( (X1-X0)*4 )) , port_rcv_data +$(( (R1-R0)*4 ))  (nonzero => data went over IB = RDMA)"
fi

#!/usr/bin/env bash
# raw RDMA-WRITE bandwidth (--bw) + IB port-counter RDMA proof.
# The client posts N signaled RDMA_WRITEs of `size` keeping the send queue full
# (depth 64) and times the burst; the server is passive. Reports Gbit/s. IB
# port_xmit_data delta (client) / port_rcv_data delta (server) proves the bytes
# crossed the InfiniBand fabric (RDMA), not TCP. Counters are 4-byte words.
#   genie (server): ./bench.sh server <ibdev> <port> <N> [size_bytes]
#   guest (client): ./bench.sh client <peer-ip> <ibdev> <port> <N> [size_bytes]
set -eu
BIN="${BIN:-}"
if [ -z "$BIN" ]; then for c in ./snp_rdma_test "$HOME/snp_rdma_test" "$(dirname "$0")/snp_rdma_test"; do [ -x "$c" ] && BIN="$c" && break; done; fi
[ -x "$BIN" ] || { echo "snp_rdma_test not found (set BIN=)"; exit 1; }
ctr() { cat "/sys/class/infiniband/$1/ports/1/counters/$2" 2>/dev/null || echo 0; }
role="${1:?role: server|client}"; shift
if [ "$role" = server ]; then
  DEV="$1"; PORT="$2"; N="$3"; SIZE="${4:-4194304}"
  echo "[server] BW target: dev=$DEV port=$PORT (passive; --bw $N, size $SIZE)"
  exec "$BIN" --server --malloc --bw "$N" -s "$SIZE" -d "$DEV" -p "$PORT"
else
  PEER="$1"; DEV="$2"; PORT="$3"; N="$4"; SIZE="${5:-4194304}"
  X0=$(ctr "$DEV" port_xmit_data); R0=$(ctr "$DEV" port_rcv_data)
  "$BIN" --client "$PEER" --malloc --bw "$N" -s "$SIZE" -d "$DEV" -p "$PORT"
  X1=$(ctr "$DEV" port_xmit_data); R1=$(ctr "$DEV" port_rcv_data)
  echo "[client] IB fabric bytes this run: port_xmit_data +$(( (X1-X0)*4 )) (expect ~$((N*SIZE))), port_rcv_data +$(( (R1-R0)*4 ))"
  echo "         nonzero xmit delta ⇒ data crossed the IB fabric = real RDMA (not TCP)."
fi
